﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Raio inválido");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(TxtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                TxtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                TxtVolume.Text = volume.ToString("N2");
                //N2 indica a quantia de casas após a vírgula.
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            TxtAltura.Text = String.Empty;
            TxtVolume.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || (raio<=0))
            {
                MessageBox.Show("Raio inválido");
            }
            //else if(raio<=0)
            //{
            //    MessageBox.Show("Raio deve ser menor que 0");
            //}
        }
    }
}
