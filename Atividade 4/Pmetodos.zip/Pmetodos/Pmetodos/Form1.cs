﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Apagar
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<frmexercicio2>().Count() > 0)
            {
                Application.OpenForms["frmexercicio2"].BringToFront();
                //Checa se a guia já está na memória antes de abri-la,
                //Se estiver, ele a traz para a frente da tela
            }
            else
            {
                //Se não, cria
                frmexercicio2 frm2 = new frmexercicio2();
                frm2.MdiParent = this; //Indica o componente pai
                frm2.WindowState = FormWindowState.Maximized; //Deixa maximzado encima do form
                frm2.Show();
            }
        }
    }
}
