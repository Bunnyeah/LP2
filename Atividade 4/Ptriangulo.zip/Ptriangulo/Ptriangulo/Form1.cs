﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txttypetri.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            //Verificar se é número
            if (!Double.TryParse(txtA.Text, out A))
            {
                MessageBox.Show("Valor de A inválido");
                txtA.Focus();
            }
            else if (!Double.TryParse(txtB.Text, out B))
            {
                MessageBox.Show("Valor de B inválido");
                txtB.Focus();
            }
            else if (!Double.TryParse(txtC.Text, out C))
            {
                MessageBox.Show("Valor de C inválido");
                txtC.Focus();
            }
            // Verificar se é triângulo
            else
            {
                if (!(((B - C) < A && A < B + C) ||
                       ((A - C) < B && B < A + C) ||
                       ((A - B) < C && C < A + B)))
                {
                    txttypetri.Text = "Não é um triângulo";
                }
                else
                {
                    if ((A == B) & (B == C)) { txttypetri.Text = "Equilátero"; }
                    else if ((A != B) & (B != C) & (A != C)) { txttypetri.Text = "Isósceles"; }
                    else { txttypetri.Text = "Escaleno"; }
                }
            }


        }
    }
}
