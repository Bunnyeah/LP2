﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string resultado;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textPesoAtual.Clear();
            textAltura.Clear();
            textIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textPesoAtual.Text, out peso) || (peso <= 0))
            {
                MessageBox.Show("Peso inválido");
                textPesoAtual.Focus();
            }
            else if (!Double.TryParse(textAltura.Text, out altura) || (altura <= 0))//out retorna um bool, a função seguinte verifica se deu veradeiro ou falso
            {
                MessageBox.Show("Altura inválida");
                textAltura.Focus();
            }
            else
            {
                imc = peso / (Math.Pow(altura, 2));
                imc = Math.Round(imc, 1);

                if (imc > 40) { textIMC.Text = "Obesidade Grave"; }
                else if (imc >= 30) { textIMC.Text = "Obesidade"; }
                else if (imc >= 25) { textIMC.Text = "Sobrepeso"; }
                else if (imc >= 18.5) { textIMC.Text = "Normal"; }
                else if (imc >= 00) { textIMC.Text = "Magreza"; }
                else { textIMC.Text = "Erro Desconhecido :("; };
            }
        }
    }
}
