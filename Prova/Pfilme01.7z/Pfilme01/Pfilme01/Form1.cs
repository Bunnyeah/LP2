﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Pfilme01.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[2, 1];

            double mediaFilm1 = 0;
            double mediaFilm2 = 0;

            for (int j = 0; j <= 1; j++)
            {
                for (int i = 0; i <= 2; i++)
                {
                    string valor = Interaction.InputBox($"Sua nota para o filme " + $"{j + 1}", matriz[i, j]);
                    mediaFilm1 = mediaFilm1 + matriz[i, 0];
                    mediaFilm2 = mediaFilm2 + matriz[i, 1];

                    mediaFilm1 = mediaFilm1 / 3;
                    mediaFilm2 = mediaFilm2 / 3;
                    txtList.Text = ("Valores:" + matriz + "\n " +
                        "Média do filme 1:" + mediaFilm1 + "\n Média do Filme 2: " + mediaFilm2);
                }
            }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtList.ClearSelected();
        }
    }
}
